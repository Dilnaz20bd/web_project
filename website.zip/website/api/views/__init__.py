from .generics_views import ImageListAPIView, ShippingListAPIView, ProductListAPIView, ImageDetailAPIView, \
   CommentListAPIView, CategoryListAPIView, ProductDetailAPIView, CategoryDetailAPIView,ShippingDetailAPIView,CommentDetailAPIView

from .fbv_views import *
